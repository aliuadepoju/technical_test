$(document).ready(function(e){
	
	// process plate request
    $("form.plateRequest").on('submit',function(e){
        e.preventDefault();
		
        $("#submit").val('Connecting...');
		
        //var form = $(this);
		var formData = new FormData(this);
        
        var url = 'http://127.0.0.1/frsc/public/api/registerPlate';
        
        $.ajax({
            type: "POST",
            url: url,
			data: formData,
			success: function(data){
				if(!data){
					alert("An error occured, please try again.");
					$("#submit").val('Submit');
				}
				else if(data == 1){
					alert("Success!");
				}
				else{
					alert("Failed to send request, please try again.");
					$("#submit").val('Submit');
				}
				
				$("#submit").val('Success!');
                document.location.href = "success.html";
			},
			cache: false,
			contentType: false,
			processData: false
        });
    });
	
	// fetch number plate records
	var url = 'http://127.0.0.1/frsc/public/api/view';
	var numberPlates = '';
	
	$.ajax({url: url, success: function(result){
		$.each(result, function(index, value){
			n = value.number;
			number = String('00000' + n).slice(-3);
			
			numberPlates+='<tr><td>'+value.id+'</td> <td>'+value.name+'</td> <td>'+value.email+'</td> <td>'+value.LGA+number+value.surfix+'</td></tr>';
		});
		$("#numberPlates").html(numberPlates);
	}});
});