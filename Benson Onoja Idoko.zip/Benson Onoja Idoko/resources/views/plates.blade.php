@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center">{{ __('Number plates') }}</div>

                <div class="card-body">
                  <div class="table-responsive">
<table class="table">
  <thead>
    <tr>
      <th>#</th>
      <th>name</th>
      <th>email</th>
      <th>Number Plate</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      @foreach ($users as $user)
        {{ $user->name }}
    @endforeach
    </tr>
  </tbody>
</table>
</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
