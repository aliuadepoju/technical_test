<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\NumberPlates;

class NumberPlatesController extends Controller
{
    //
    public function view(){
      $numberPlates = NumberPlates::get();

      return $numberPlates;
    }

    public function registerPlate(Request $request){

      //return $request->all();

      $this->validate(request(), [
        'name' => 'required',
        'email' => 'required|email',
        'LGA' => 'required',
        'quantity' => 'required'
      ]);

      $countPlates = $request->get('quantity');
        if($getLastRegistrationNumber = NumberPlates::orderBy('id', 'desc')->first(['number', 'surfix'])){
          // continue
          $platePartials[] = $getLastRegistrationNumber->toArray();

          $result = array();
          $count = 0;

          foreach ($platePartials as $i => $values) {

              foreach ($values as $key => $value) {
                  $result[$count] = $value;
                  $count++;
              }
          }

          $number = $result[0];

          $surfix = $result[1];

          $lastChar = substr($surfix, -1);

          $firstChar =substr($surfix, 0, 1);

          if($number > 0 && $number < 999){
            $number ++;
          }

          else if($number = 999){
            $number = 001;
            $surfix ++;
          }
        }
        else{
          $number = 001;

          $surfix = 'AA';
        }


      do{
        $request->merge([
            'number' => $number,
            'surfix' => $surfix
        ]);

        NumberPlates::create(request(['name', 'email', 'LGA', 'number', 'surfix', 'quantity']));

        $countPlates --;
        $number ++;
      }

      while($countPlates > 0);

      return 1;
    }

    //printf("%03d", $number);
}
