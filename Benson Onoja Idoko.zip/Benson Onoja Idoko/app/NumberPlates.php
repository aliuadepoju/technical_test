<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NumberPlates extends Model
{
    //
    protected $fillable = [
        'name', 'email', 'LGA', 'number', 'surfix', 'quantity'
    ];
}
