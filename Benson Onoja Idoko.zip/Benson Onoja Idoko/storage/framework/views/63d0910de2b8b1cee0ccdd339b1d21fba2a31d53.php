<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center"><?php echo e(__('Number plates')); ?></div>

                <div class="card-body">
                  <div class="table-responsive">
<table class="table">
  <thead>
    <tr>
      <th>#</th>
      <th>name</th>
      <th>email</th>
      <th>Number Plate</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <?php return $numberPlates; ?>
    </tr>
  </tbody>
</table>
</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>