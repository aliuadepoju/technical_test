<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Request Number Plate')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('/registerPlate')); ?>" aria-label="<?php echo e(__('registerPlate')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="LGA" class="col-md-4 col-form-label text-md-right"><?php echo e(__('LGA')); ?></label>

                            <div class="col-md-6">
                                <select id="LGA" name="LGA" class="selectpicker form-control<?php echo e($errors->has('LGA') ? ' is-invalid' : ''); ?>" data-live-search="true" title="Please select LGA">
                                  <option value="ABJ">Abaji</option>
                                  <option value="ABC">Abuja Municipal</option>
                                  <option value="GWA">Gwagwalada</option>
                                  <option value="KUJ">Kuje</option>
                                  <option value="BWR">Bwari</option>
                                  <option value="KWL">Kwali</option>
                                </select>

                                <?php if($errors->has('LGA')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('LGA')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="quantity" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Quantity')); ?></label>

                            <div class="col-md-6">
                                <input id="quantity" type="number" class="form-control<?php echo e($errors->has('quantity') ? ' is-invalid' : ''); ?>" name="quantity" required>

                                <?php if($errors->has('quantity')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('quantity')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="notify" <?php echo e(old('notify') ? 'checked' : ''); ?>> <?php echo e(__('Notify Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>

                                <a class="btn btn-link" href="">
                                    <?php echo e(__('Track Registration?')); ?>

                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>